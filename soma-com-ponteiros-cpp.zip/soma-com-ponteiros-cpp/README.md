# Projeto: Soma de Dois Números Usando Ponteiros – C++

Este projeto realiza a soma de dois números inteiros utilizando **apenas ponteiros** para acessar os valores das variáveis. Foi desenvolvido como exercício da disciplina **Estrutura de Dados I**, no 3° semestre do curso de Engenharia de Software.

## 🧠 Conceitos utilizados
- Ponteiros (`*`)
- Endereçamento (`&`)
- Entrada/Saída com `cin` e `cout`

## ▶ Como compilar e executar

```bash
g++ main.cpp -o soma
./soma
```

Desenvolvido por: **Julia Alli**
