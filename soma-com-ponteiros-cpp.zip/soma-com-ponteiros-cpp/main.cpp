#include <iostream>
using namespace std;

int main() {
    int n1, n2, result;
    int *p1, *p2;

    // Ponteiros apontando para as variáveis
    p1 = &n1;
    p2 = &n2;

    cout << "===== SOMA USANDO PONTEIROS =====" << endl;

    cout << "Digite o primeiro numero: ";
    cin >> n1;

    cout << "Digite o segundo numero: ";
    cin >> n2;

    // Soma usando apenas os ponteiros
    result = *p1 + *p2;

    cout << "\nA soma dos valores eh: " << result << endl;
    cout << "===============================" << endl;

    return 0;
}
